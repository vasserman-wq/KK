# Опись обращений к Excel (этап 0)

Сгенерировано статическим разбором текста макросов 16.11.2026. Группы назначены по ключевым словам и требуют ручной проверки. Код не компилировался и не запускался.

## Макрос 1 (SOLIDWORKS_KC_v16.5.15_review)

Процедур всего: 436, с обращением к Excel: 96.

| Группа | Процедура | Строка | Обращений | Оформление |
|---|---|---|---|---|
| Архивы и резервные копии | `KA_AfterSuccess` | 12884 | 2 | 0 |
| Архивы и резервные копии | `KA_Archive` | 12806 | 2 | 0 |
| Архивы и резервные копии | `KA_Completed` | 12812 | 1 | 0 |
| Архивы и резервные копии | `KA_Prune` | 12838 | 4 | 0 |
| Архивы и резервные копии | `KA_SetVisibility` | 12816 | 2 | 0 |
| Архивы и резервные копии | `KC21_RenameRegularKE` | 10656 | 4 | 0 |
| Архивы и резервные копии | `KC36_AddOrphan` | 11399 | 2 | 0 |
| Архивы и резервные копии | `KC36_ArchiveRow` | 11562 | 7 | 0 |
| Архивы и резервные копии | `KC36_CheckReview` | 11340 | 5 | 0 |
| Архивы и резервные копии | `KC36_CreateArchive` | 11578 | 19 | 6 |
| Архивы и резервные копии | `KC36_PlanRaw` | 11497 | 3 | 0 |
| Архивы и резервные копии | `KC36_Quarantine` | 11628 | 3 | 0 |
| Архивы и резервные копии | `KC37_StampLayout` | 11866 | 10 | 0 |
| Архивы и резервные копии | `KC_PrepareIntroConfiguration` | 7780 | 10 | 0 |
| Архивы и резервные копии | `KD_CaptureScope` | 12298 | 3 | 0 |
| Архивы и резервные копии | `KD_CompletedArchive` | 12679 | 6 | 0 |
| Архивы и резервные копии | `KD_Finish` | 12549 | 12 | 0 |
| Архивы и резервные копии | `KD_LoadPending` | 12509 | 10 | 0 |
| Вводные пункты | `ApplyCardOperationLayout` | 7333 | 5 | 2 |
| Вводные пункты | `KC14_Snapshot` | 7931 | 5 | 0 |
| Вводные пункты | `KC47_CommitCard` | 13156 | 7 | 0 |
| Вводные пункты | `KC_CopyConfirmedTools` | 7478 | 3 | 0 |
| Вводные пункты | `KC_EditorMeta` | 7628 | 2 | 0 |
| Вводные пункты | `KC_OpenMarkerBook` | 5161 | 5 | 0 |
| Вводные пункты | `ReadOldExcelData` | 2876 | 6 | 0 |
| Вводные пункты | `WriteIntroOperations` | 7132 | 3 | 2 |
| Диалоги файлов | `KC14_OptionalXlsx` | 8434 | 15 | 8 |
| Диалоги файлов | `KC30_RebindMissing` | 9708 | 14 | 0 |
| Диалоги файлов | `RunMode3_SaveStars` | 3890 | 26 | 5 |
| Карта и служебные данные | `KA_Owner` | 12695 | 2 | 0 |
| Карта и служебные данные | `KC30_ValidateSource` | 9682 | 10 | 0 |
| Карта и служебные данные | `KC35_MapRaw` | 11306 | 6 | 0 |
| Карта и служебные данные | `KC35_ValidateRaw` | 11298 | 2 | 0 |
| Карта и служебные данные | `KC37_CheckMigrationBook` | 11753 | 2 | 0 |
| Карта и служебные данные | `KD_CanRebuild` | 12270 | 6 | 0 |
| Маркеры # и @ | `ExportToExcel` | 4360 | 36 | 23 |
| Маркеры # и @ | `KC15_IntroLast` | 8484 | 3 | 0 |
| Маркеры # и @ | `KC35_PlanMarkers` | 11156 | 10 | 0 |
| Маркеры # и @ | `KC36_Missing` | 11360 | 13 | 0 |
| Маркеры # и @ | `KC36_PlanMarkers` | 11418 | 20 | 0 |
| Маркеры # и @ | `KC50_ResolveMovedMarkers` | 13270 | 23 | 0 |
| Маркеры # и @ | `KC_ApplyHashesFromFile` | 4736 | 18 | 0 |
| Маркеры # и @ | `KC_MarkerSheet` | 5123 | 1 | 0 |
| Маркеры # и @ | `KC_ParseMarkerBook` | 5503 | 29 | 0 |
| Маркеры # и @ | `KC_WriteMarkerSheet` | 5219 | 21 | 10 |
| Маркеры # и @ | `KD_ValidatePending` | 12406 | 23 | 0 |
| Маркеры # и @ | `RunMode1_BalloonsAndCard` | 3238 | 2 | 0 |
| Настройки | `KC28_AddToolName` | 10188 | 1 | 2 |
| Настройки | `KC28_AppendRuleTools` | 9791 | 1 | 0 |
| Настройки | `KC28_Load` | 9193 | 37 | 2 |
| Настройки | `KC28_ReadRuleTable` | 9989 | 6 | 0 |
| Прочее | `FormatCardOperationBlock` | 7318 | 5 | 2 |
| Прочее | `KA_RestoreVisibility` | 12832 | 1 | 0 |
| Прочее | `KC14_Open` | 7865 | 2 | 0 |
| Прочее | `KC14_WriteParameter` | 7996 | 12 | 0 |
| Прочее | `KC35_OpenBook` | 10890 | 2 | 0 |
| Прочее | `KC35_Sheet` | 10925 | 1 | 0 |
| Прочее | `KC35_WriteMarkerOwners` | 11281 | 5 | 0 |
| Прочее | `KC37_CheckLayoutSlot` | 11695 | 2 | 0 |
| Прочее | `KC37_InvalidateCopiedLayout` | 11705 | 5 | 0 |
| Прочее | `KC37_MarkerOwnersChanged` | 11901 | 3 | 0 |
| Прочее | `KC47_CheckCardFormulas` | 13123 | 1 | 0 |
| Прочее | `KC49_MarkerMismatch` | 13206 | 4 | 0 |
| Прочее | `KC53_Finish` | 13605 | 1 | 0 |
| Прочее | `KC53_TakeExcel` | 13616 | 2 | 0 |
| Прочее | `KCPerf_GroupBorders` | 8722 | 1 | 5 |
| Прочее | `KC_FindOpenBook` | 5130 | 1 | 0 |
| Прочее | `KC_LoadCombinedRows` | 5581 | 2 | 0 |
| Прочее | `KR_WriteLayout` | 12216 | 16 | 0 |
| Прочее | `LastOKContinuationRow` | 7017 | 1 | 0 |
| Прочее | `OK1ExcelText` | 6974 | 2 | 0 |
| Средства ТО | `EnsureCardToolsList` | 7246 | 4 | 0 |
| Средства ТО | `KCPerf_Layout` | 8694 | 6 | 8 |
| Средства ТО | `NeedsCardToolValidation` | 7298 | 3 | 3 |
| Шапка и реквизиты | `GetIntroSource` | 7051 | 2 | 0 |
| Шапка и реквизиты | `InitializeUnifiedExport` | 7151 | 1 | 0 |
| Шапка и реквизиты | `KC14_Import` | 8344 | 24 | 0 |
| Шапка и реквизиты | `KC23_Band` | 8889 | 2 | 5 |
| Шапка и реквизиты | `KC23_CellText` | 8843 | 1 | 0 |
| Шапка и реквизиты | `KC23_CopyPanel` | 9008 | 6 | 0 |
| Шапка и реквизиты | `KC23_EnsureLayout` | 8900 | 41 | 34 |
| Шапка и реквизиты | `KC23_Field` | 8828 | 1 | 0 |
| Шапка и реквизиты | `KC23_FixedCell` | 8850 | 1 | 0 |
| Шапка и реквизиты | `KC23_Name` | 8857 | 1 | 0 |
| Шапка и реквизиты | `KC23_ReadHeader` | 8993 | 2 | 0 |
| Шапка и реквизиты | `KC23_RegisterNames` | 8864 | 2 | 0 |
| Шапка и реквизиты | `KC27_ReadPrimary` | 9856 | 1 | 0 |
| Шапка и реквизиты | `KC29_EnsureHeaderData` | 9884 | 23 | 19 |
| Шапка и реквизиты | `KC29_NewFields` | 9836 | 2 | 0 |
| Шапка и реквизиты | `KC29_ReadHeaderData` | 9869 | 2 | 0 |
| Шапка и реквизиты | `KC29_TextField` | 9840 | 2 | 1 |
| Шапка и реквизиты | `KC33_LoadRefs` | 10234 | 5 | 0 |
| Шапка и реквизиты | `KC_ImportPreviousIntro` | 7722 | 5 | 0 |
| Шапка и реквизиты | `KC_ReadIntroEditor` | 7424 | 1 | 0 |
| Шапка и реквизиты | `KC_WriteIntroSummary` | 7472 | 2 | 0 |
| Шапка и реквизиты | `WriteFixedCardBlock` | 7124 | 1 | 1 |

## Макрос 2 (2 Макрос (2).txt)

Процедур всего: 288, с обращением к Excel: 58.

| Группа | Процедура | Строка | Обращений | Оформление |
|---|---|---|---|---|
| Архивы и резервные копии | `KC36_AddOrphan` | 7077 | 2 | 0 |
| Архивы и резервные копии | `KC36_ArchiveRow` | 7214 | 7 | 0 |
| Архивы и резервные копии | `KC36_CheckReview` | 7022 | 5 | 0 |
| Архивы и резервные копии | `KC36_CreateArchive` | 7229 | 19 | 6 |
| Архивы и резервные копии | `KC36_Missing` | 7039 | 13 | 0 |
| Архивы и резервные копии | `KC36_PlanMarkers` | 7095 | 15 | 0 |
| Архивы и резервные копии | `KC36_PlanRaw` | 7154 | 3 | 0 |
| Архивы и резервные копии | `KC36_Quarantine` | 7278 | 3 | 0 |
| Архивы и резервные копии | `KC37_ValidateForFill` | 7362 | 25 | 0 |
| Архивы и резервные копии | `KD_CompletedArchive` | 7534 | 6 | 0 |
| Вводные пункты | `KC20_IntroCount` | 4693 | 1 | 0 |
| Вводные пункты | `WriteIntroOperations` | 3410 | 8 | 6 |
| Диалоги файлов | `KC30_RebindMissing` | 6118 | 14 | 0 |
| Маркеры # и @ | `KC15_IntroLast` | 4425 | 3 | 0 |
| Маркеры # и @ | `KC_ValidateCardNumbering` | 4105 | 1 | 0 |
| Маркеры # и @ | `Main` | 1564 | 1 | 0 |
| Настройки | `KC28_Load` | 5506 | 37 | 2 |
| Настройки | `KC28_ReadRuleTable` | 6483 | 6 | 0 |
| Прочее | `BrowseForFile` | 424 | 2 | 0 |
| Прочее | `ExcelTimeValue` | 3603 | 2 | 0 |
| Прочее | `KC14_CheckReady` | 4292 | 3 | 0 |
| Прочее | `KC14_FillBook` | 4275 | 3 | 0 |
| Прочее | `KC30_ValidateSource` | 6093 | 10 | 0 |
| Прочее | `KC35_MapRaw` | 6991 | 6 | 0 |
| Прочее | `KC35_OpenBook` | 6621 | 3 | 0 |
| Прочее | `KC35_PlanMarkers` | 6850 | 10 | 0 |
| Прочее | `KC35_Sheet` | 6665 | 1 | 0 |
| Прочее | `KC35_ValidateRaw` | 6984 | 2 | 0 |
| Прочее | `KC35_WriteMarkerOwners` | 6965 | 5 | 0 |
| Прочее | `KC37_CheckLayoutSlot` | 7341 | 2 | 0 |
| Прочее | `KC37_InvalidateCopiedLayout` | 7350 | 5 | 0 |
| Прочее | `KE_ExcelViewReference` | 2157 | 2 | 0 |
| Прочее | `LastOKContinuationRow` | 3301 | 1 | 0 |
| Прочее | `OK1ExcelText` | 3263 | 2 | 0 |
| Средства ТО | `EnsureCardToolsList` | 3828 | 4 | 0 |
| Средства ТО | `FormatCardOperationBlock` | 3897 | 5 | 11 |
| Средства ТО | `NeedsCardToolValidation` | 3878 | 3 | 3 |
| Шапка и реквизиты | `GetIntroSource` | 3332 | 2 | 0 |
| Шапка и реквизиты | `InitializeUnifiedExport` | 3427 | 1 | 0 |
| Шапка и реквизиты | `KC23_Band` | 5069 | 2 | 5 |
| Шапка и реквизиты | `KC23_CellText` | 5027 | 1 | 0 |
| Шапка и реквизиты | `KC23_CopyPanel` | 5185 | 6 | 0 |
| Шапка и реквизиты | `KC23_EnsureLayout` | 5079 | 41 | 34 |
| Шапка и реквизиты | `KC23_Field` | 5013 | 1 | 0 |
| Шапка и реквизиты | `KC23_FixedCell` | 5033 | 1 | 0 |
| Шапка и реквизиты | `KC23_Name` | 5039 | 1 | 0 |
| Шапка и реквизиты | `KC23_ReadHeader` | 5171 | 2 | 0 |
| Шапка и реквизиты | `KC23_RegisterNames` | 5045 | 2 | 0 |
| Шапка и реквизиты | `KC27_ReadPrimary` | 6231 | 1 | 0 |
| Шапка и реквизиты | `KC29_EnsureHeaderData` | 6257 | 23 | 19 |
| Шапка и реквизиты | `KC29_NewFields` | 6213 | 2 | 0 |
| Шапка и реквизиты | `KC29_ReadHeaderData` | 6243 | 2 | 0 |
| Шапка и реквизиты | `KC29_TextField` | 6216 | 2 | 1 |
| Шапка и реквизиты | `KC31_ReadCell` | 6311 | 1 | 0 |
| Шапка и реквизиты | `KC31_ValidateCard` | 6323 | 1 | 0 |
| Шапка и реквизиты | `KE_ExcelHeaderColumn` | 2142 | 2 | 0 |
| Шапка и реквизиты | `LoadKEWeldsFromExcel` | 2441 | 17 | 0 |
| Шапка и реквизиты | `WriteFixedCardBlock` | 3403 | 1 | 1 |
