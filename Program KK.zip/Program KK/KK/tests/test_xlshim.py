"""Тесты эмулятора (без COM): поведение должно совпадать с Excel в приёмах, которые используют макросы."""
import openpyxl
import pytest

from kk.xlshim import Factory, ShimError, parse_address
from kk.xlshim.com import GET, METHOD, PUT, Coll, dispatch


@pytest.fixture
def book(tmp_path):
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = 'Карта контроля'
    for r, key in ((7, '01'), (11, '02'), (15, '03')):
        ws.cell(r, 1, key)
        ws.cell(r, 2, f'{int(key)}. пункт')
        ws.cell(r, 5, 1.5)
    ws.cell(4, 8, 'Разраб.')
    svc = wb.create_sheet('ОК_Служебное')
    svc['A10'], svc['B10'] = 'CardState', 'READY'
    path = tmp_path / 'Ч — карта контроля.xlsm'
    wb.save(path)
    app = Factory().new_app()
    return app, app.open(str(path)), path


def test_parse_address():
    assert parse_address("='СписокТО'!$A$1:$A$14") == ('СписокТО', 1, 1, 14, 1)
    assert parse_address('A:A')[1:] == (1, 1, 1048576, 1)


def test_values_and_end(book):
    app, b, _ = book
    ws = b.sheet('Карта контроля')
    assert ws.cells(7, 1).get_value2() == '01'
    assert ws.cells(7, 5).get_value2() == 1.5
    assert ws.cells(ws.rows().nrows, 1).end(-4162).r1 == 15
    assert ws.range('A7:B7').get_value2() == [['01', '1. пункт']]
    assert ws.cells(100, 1).get_value2() is None


def test_insert_delete_shift_only_ae(book):
    app, b, _ = book
    ws = b.sheet(1)
    ws.range('A11:E14').insert()
    assert ws.cells(15, 1).get_value2() == '02' and ws.cells(4, 8).get_value2() == 'Разраб.'
    ws.range('A11:E14').delete()
    assert ws.cells(11, 1).get_value2() == '02' and ws.cells(15, 1).get_value2() == '03'


def test_save_roundtrip_and_readonly(book, tmp_path):
    app, b, path = book
    b.sheet('ОК_Служебное').range('B10').set_value2('PENDING')
    assert b.saved is False
    b.save()
    app2 = app.factory.new_app()
    other = app2.open(str(path), 0, True)
    assert other.sheet('ОК_Служебное').range('B10').get_value2() == 'PENDING'
    with pytest.raises(ShimError):
        other.save()


def test_names_and_dispatch(book):
    app, b, _ = book
    b.names.add('ToolsList', "='Карта контроля'!$A$7:$A$15")
    rng = dispatch(b, 'Names', GET, ('ToolsList',), app.factory)
    rng = dispatch(rng, 'RefersToRange', GET, (), app.factory)
    assert rng.nrows == 9
    ws = dispatch(b, 'Worksheets', GET, ('Карта контроля',), app.factory)
    cell = dispatch(ws, 'cells', GET | METHOD, (7, 2), app.factory)
    assert dispatch(cell, 'Value2', GET, (), app.factory) == '1. пункт'
    dispatch(cell, '_value_', PUT, ('новый',), app.factory)
    assert ws.cells(7, 2).get_value2() == 'новый'
    font = dispatch(cell, 'Font', GET, (), app.factory)
    assert dispatch(font, 'Bold', PUT, (True,), app.factory) is None
    rows = dispatch(ws, 'Rows', GET, (), app.factory)
    assert isinstance(rows, Coll) and dispatch(rows, 'Count', GET, (), app.factory) == 1048576
    new = dispatch(dispatch(b, 'Worksheets', GET, (), app.factory), 'Add', METHOD, (None, ws), app.factory)
    assert b.sheets()[1] is new
    assert dispatch(app, 'Run', METHOD, ("'x.xlsm'!OK_EditorPing",), app.factory) == 'OK_INTRO_EDITOR_V19'


def test_factory_decisions():
    f = Factory()
    assert f.decision('c:/a.slddrw', 'КЭ1', 'D4', 0.1, 0.2) == -1
    f.set_decisions('C:/A.SLDDRW', [('КЭ1', 'D4', 0.1, 0.2, False), ('КЭ1', 'Заметки1', 0.3, 0.2, True),
                                   ('КЭ2', 'D1', 0.1, 0.1, True), ('КЭ2', 'D1', 0.2, 0.1, False)])
    assert f.decision('c:/a.slddrw', 'КЭ1', 'D4', 0.10001, 0.2) == 0
    assert f.decision('c:/a.slddrw', 'КЭ1', 'Заметки1', 0.3, 0.2) == 1
    assert f.decision('c:/a.slddrw', 'КЭ1', 'D4', 0.11, 0.2) == -1   # сдвинут: решения нет
    assert f.decision('c:/a.slddrw', 'КЭ2', 'D1', 0.2, 0.1) == 0     # одинаковые имена в разных видах
    assert f.decision('c:/other.slddrw', 'КЭ1', 'D4', 0.1, 0.2) == -1
    f.set_command('mode', '1')
    assert f.take_command('MODE') == '1' and f.take_command('mode') == ''
