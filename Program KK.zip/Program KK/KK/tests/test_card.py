"""Модель карты на примере КК D10ДМ.11.000 Рама (значения и имена из рабочей книги)."""
import shutil
from pathlib import Path

import pytest

from kk.card import Card, default_card_path, numbered_text, percent_text

DATA = Path(__file__).parent / 'data' / 'example_card.xlsx'


@pytest.fixture
def card(tmp_path):
    path = tmp_path / 'КК D10ДМ.11.000 Рама — карта контроля.xlsx'
    shutil.copy(DATA, path)
    return Card(path)


def test_helpers():
    assert numbered_text('12. 905±2 мм', 4) == '4. 905±2 мм'
    assert numbered_text('905±2 мм', 4) == '4. 905±2 мм'
    assert percent_text(1) == '100%' and percent_text('50') == '50%' and percent_text('100%') == '100%'
    assert default_card_path('/Ч/D10.SLDDRW').name == 'D10 — карта контроля.xlsm'


def test_blocks_like_example(card):
    blocks = card.blocks()
    assert len(blocks) == 249
    assert [b.kind for b in blocks[:4]] == ['intro', 'intro', 'intro', 'param']
    assert blocks[3].key == '04' or blocks[3].number == 4
    stamp = blocks[-1]
    assert stamp.kind == 'stamp' and stamp.number == 249
    assert stamp.tools[0] == 'Клеймо ОТК' and len(stamp.tools) == 3
    t = card.totals(blocks)
    assert t['intro'] == 3 and t['stamp'] == 1 and abs(t['minutes'] - 261.0) < 1e-9


def test_header_and_tools(card):
    h = card.header()
    assert h['equipment'] == 'Контрольный стол'
    assert h['fixed_rows'][0].startswith('Контролер ОТК')
    assert len(h['signatures']) == 5
    assert 'Визуально' in card.tools_list()
    errors = [m for lvl, m in card.problems(for_macro2=True) if lvl == 'error']
    assert any('Номер КД' in m for m in errors)  # в примере реквизиты пустые
    card.set_header(kd_number='D10ДМ.11.000', product_name='Рама', mass='12,5')
    assert card.header()['mass'] == '12.5'


def test_add_delete_intro_keeps_params(card):
    before = card.blocks()
    first_param = next(b for b in before if b.kind == 'param')
    card.add_intro(after=before[0])
    after = card.blocks()
    assert [b.kind for b in after].count('intro') == 4
    assert after[1].key == '02' and after[1].text == ''
    moved = next(b for b in after if b.kind == 'param')
    assert moved.text == first_param.text and moved.row == first_param.row + 4
    assert card.state == 'PENDING'
    assert card.ws.range('I25').get_value2() == 4.0   # первый баллон: пустой блок не считается
    card.delete_intro(after[1])
    again = card.blocks()
    assert [b.text for b in again] == [b.text for b in before]
    assert card.ws.range('H18').get_value2() == 'Оборудование ОК1'  # панель H:I не сдвигается


def test_edit_block_rules(card):
    b = next(x for x in card.blocks() if x.kind == 'param')
    assert not b.can_edit('key') and b.can_edit('text')
    card.update_block(b, text='905±3 мм. Эскиз 1.', tools=['Рулетка Р5У2П ГОСТ 7502-98', 'Лупа ГОСТ 25706-83'], minutes='1,5')
    b2 = next(x for x in card.blocks() if x.row == b.row)
    assert b2.text == '4. 905±3 мм. Эскиз 1.' and b2.minutes == 1.5 and len(b2.tools) == 2
    with pytest.raises(Exception):
        card.update_block(b2, minutes='много')
    card.save()
    again = Card(card.path)
    assert next(x for x in again.blocks() if x.row == b.row).minutes == 1.5


def test_stamp_exists(card):
    with pytest.raises(Exception):
        card.add_stamp()
