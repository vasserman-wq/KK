Attribute VB_Name = "KK_Bridge"
' Связь макросов с программой KK. Вместо Excel макросы получают эмулятор Excel из программы
' (GetObject(, "KK.ExcelShim")). НЕ КОМПИЛИРОВАЛОСЬ: после импорта выполните Debug > Compile.
Option Explicit

Private gKKFactory As Object

Public Function KK_Factory() As Object
    If gKKFactory Is Nothing Then
        On Error Resume Next
        Set gKKFactory = GetObject(, "KK.ExcelShim")
        On Error GoTo 0
    End If
    Set KK_Factory = gKKFactory
End Function

' Замена CreateObject("Excel.Application") (newInstance = True) и GetObject(, "Excel.Application") (False).
' Как и с Excel, GetObject без запущенного экземпляра даёт ошибку (её перехватывает On Error Resume Next).
Public Function KK_Excel(ByVal newInstance As Boolean) As Object
    Dim f As Object
    Set f = KK_Factory()
    If f Is Nothing Then Err.Raise vbObjectError + 7001, "KK_Excel", _
        "Программа KK не запущена. Этот макрос работает только из программы KK, Excel не используется."
    If newInstance Then
        Set KK_Excel = f.NewApp()
    Else
        Set KK_Excel = f.ActiveApp()
    End If
End Function

' Команда программы (например, режим "1"). Читается один раз; пусто — спросить пользователя как раньше.
Public Function KK_Command(ByVal name As String) As String
    Dim f As Object
    Set f = KK_Factory()
    If f Is Nothing Then Exit Function
    On Error Resume Next
    KK_Command = CStr(f.Command(name))
End Function

Private Function KK_DrawingPath() As String
    Dim doc As Object
    On Error Resume Next
    Set doc = Application.SldWorks.ActiveDoc
    If Not doc Is Nothing Then KK_DrawingPath = CStr(doc.GetPathName)
End Function

' True: решения о включении в карту переданы программой, маркеры # и @ в чертёж не пишутся.
Public Function KK_HasDecisions() As Boolean
    Dim f As Object
    Set f = KK_Factory()
    If f Is Nothing Then Exit Function
    On Error Resume Next
    KK_HasDecisions = CBool(f.HasDecisions(KK_DrawingPath()))
End Function

' -1: решения нет (прежнее правило маркеров), 0: не включать, 1: включить.
Public Function KK_Decision(ByVal sheetName As String, ByVal ann As Object) As Long
    Dim f As Object, pos As Variant, annName As String
    KK_Decision = -1
    If ann Is Nothing Then Exit Function
    Set f = KK_Factory()
    If f Is Nothing Then Exit Function
    On Error GoTo Failed
    pos = ann.GetPosition()
    If Not IsArray(pos) Then Exit Function
    annName = CStr(ann.GetName)
    KK_Decision = CLng(f.Decision(KK_DrawingPath(), sheetName, annName, CDbl(pos(0)), CDbl(pos(1))))
    Exit Function
Failed:
    KK_Decision = -1
End Function

' Замена NoteHasMark при обходе заметок: решение программы, а если его нет — маркер @ как раньше.
Public Function KK_NoteWanted(ByVal note As Object, ByVal sheetName As String) As Boolean
    Dim d As Long, t As String
    If note Is Nothing Then Exit Function
    d = KK_Decision(sheetName, note.GetAnnotation)
    If d >= 0 Then
        KK_NoteWanted = (d = 1)
        Exit Function
    End If
    On Error Resume Next
    t = CStr(note.GetText)
    If Err.Number <> 0 Then Exit Function
    On Error GoTo 0
    If InStr(1, t, "@") = 0 Then Exit Function
    If IsNumeric(Trim$(t)) Then Exit Function
    KK_NoteWanted = True
End Function
