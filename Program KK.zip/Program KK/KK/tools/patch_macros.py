#!/usr/bin/env python3
r"""Вносит в тексты макросов правки для работы через программу KK (без Excel).

    py tools\patch_macros.py "SOLIDWORKS_KC_v16.5.15_review (1).txt" "2 Макрос (2).txt" --out vba\patched

Правила точечные; остальная логика макросов не меняется. Если обязательное место не найдено ровно один раз,
скрипт останавливается и ничего не записывает. Результат: *_KK.txt в кодировке Windows-1251
(для вставки в редактор VBA) и отчёт *_KK.report.txt со всеми заменами.
"""
from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

MARK = "' KK-PATCH"

# (имя, регулярное выражение, замена, сколько раз: None = любое >= 0, n = ровно n)
COMMON = [
    ('Excel: новый экземпляр', r'CreateObject\(\s*"Excel\.Application"\s*\)', 'KK_Excel(True)', None),
    ('Excel: запущенный экземпляр', r'GetObject\(\s*,\s*"Excel\.Application"\s*\)', 'KK_Excel(False)', None),
    ('Worksheets.Add(After:=)', r'\.Add\(After:=', '.Add(, ', None),
    ('Worksheets.Add(Before:=)', r'\.Add\(Before:=', '.Add(', None),
    ('Names.Add name:=, RefersTo:=', r'(?i)(\.names\.Add)\s+name:=(.+?),\s*RefersTo:=', r'\1 \2, ', None),
]

MACRO1 = [
    ('Режим из программы вместо InputBox',
     r'^(\s*)modeInput = InputBox\("',
     r'\1modeInput = KK_Command("mode"): If Len(modeInput) = 0 Then modeInput = InputBox("', 1),
    ('Размер: решение программы вместо #',
     r'^(\s*)If KC_DimHasHash\(swDD\) Then Exit Function\s*$',
     r'\1Select Case KK_Decision(sheetName, swAnn)' + '\n' + r'\1    Case 0: Exit Function' + '\n'
     + r'\1    Case -1: If KC_DimHasHash(swDD) Then Exit Function' + '\n' + r'\1End Select', 1),
    ('Заметка в ProcessAnnotation: @ не обязателен при решениях программы',
     r'^(\s*)If Not NoteHasMark\(swNO\) Then Exit Function\s*$',
     r'\1If Not KK_HasDecisions() Then If Not NoteHasMark(swNO) Then Exit Function', 1),
    ('Обход заметок: решение программы вместо @',
     r'^(\s*)If NoteHasMark\(note\) Then\s*$', r'\1If KK_NoteWanted(note, sheetName) Then', 1),
    ('Не расставлять # и @ перед режимом 1',
     r'^(\s*)If Not KC_PrepareAutomaticMarkers\(allSheetNames, selectedSheets\) Then Exit Sub\s*$',
     r'\1If Not KK_HasDecisions() Then If Not KC_PrepareAutomaticMarkers(allSheetNames, selectedSheets) Then Exit Sub', 1),
    ('Не снимать маркеры после выгрузки (их не ставили)',
     r'^(\s*)If Not KC_CleanupMarkersAfterExport\(\) Then\s*$',
     r'\1Dim kkCleanupOk As Boolean' + '\n' + r'\1If KK_HasDecisions() Then kkCleanupOk = True Else kkCleanupOk = KC_CleanupMarkersAfterExport()'
     + '\n' + r'\1If Not kkCleanupOk Then', 1),
]


def read_text(path):
    raw = Path(path).read_bytes()
    for enc in ('utf-8-sig', 'cp1251'):
        try:
            return raw.decode(enc), enc
        except UnicodeDecodeError:
            continue
    raise SystemExit(f'Не удалось определить кодировку: {path}')


def is_macro1(text):
    return 'RunMode1_BalloonsAndCard' in text and 'KC53_MainCore' in text


def patch(text, rules):
    report = []
    for name, pattern, repl, expected in rules:
        rx = re.compile(pattern, re.MULTILINE)
        count = len(rx.findall(text))
        if expected is not None and count != expected:
            raise SystemExit(f'ОСТАНОВЛЕНО: «{name}» найдено {count} раз, ожидалось {expected}. '
                             'Версия макроса отличается от проверенной; файлы не записаны.')
        lines = [text.count('\n', 0, m.start()) + 1 for m in rx.finditer(text)]
        text = rx.sub(repl, text)
        report.append(f'{name}: {count} (строки {", ".join(map(str, lines[:40]))})')
    return text, report


def process(path, out_dir):
    text, enc = read_text(path)
    if MARK in text:
        raise SystemExit(f'Файл уже содержит правки KK: {path}')
    text = text.replace('\r\n', '\n')
    rules = COMMON + (MACRO1 if is_macro1(text) else [])
    text, report = patch(text, rules)
    left = re.findall(r'(?i)(CreateObject|GetObject)\([^)]*Excel', text)
    if left:
        raise SystemExit(f'ОСТАНОВЛЕНО: остались обращения к Excel: {left[:3]}')
    header = f"{MARK}: правки для работы через программу KK (tools/patch_macros.py). Требуется модуль KK_Bridge. Не компилировалось.\n"
    out_dir.mkdir(parents=True, exist_ok=True)
    target = out_dir / (Path(path).stem + '_KK.txt')
    try:
        data = (header + text).replace('\n', '\r\n').encode('cp1251')
    except UnicodeEncodeError as exc:
        raise SystemExit(f'ОСТАНОВЛЕНО: символ без аналога в Windows-1251 ({exc}).')
    target.write_bytes(data)
    report_path = target.with_suffix('.report.txt')
    report_path.write_text(f'Исходный файл: {path} (кодировка {enc})\n' + '\n'.join(report) + '\n', encoding='utf-8')
    return target, report


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument('files', nargs='+')
    parser.add_argument('--out', default='vba/patched')
    args = parser.parse_args(argv)
    for path in args.files:
        target, report = process(path, Path(args.out))
        print(f'Готово: {target}')
        for line in report:
            print('  ' + line)
    return 0


if __name__ == '__main__':
    sys.exit(main())
